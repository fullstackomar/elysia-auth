# elysia-project

# Setup

Follow these steps to run [Elysia.js](https://elysiajs.com) under [Bun](https://bun.sh):

1. Download packages
   ```bash
   bun install
   ```
2. You're ready to go!
   ```bash
   bun run main.ts
   ```

