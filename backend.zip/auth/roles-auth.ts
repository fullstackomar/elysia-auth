import { Context } from "elysia";
import auth from "./config";

export async function adminOnly(context: Context) {
    const cookie = context.headers.cookie;
    const sessionId = auth.readSessionCookie(cookie ?? "");

    if (!sessionId) {
        return { status: 401, body: { error: "Not authenticated" } };
    }

    const { user, session } = await auth.validateSession(sessionId);
    if (!user || user.role !== "admin") {
        return { status: 403, body: { error: "You Are not an Admin!" } };
    }

    return true;
}