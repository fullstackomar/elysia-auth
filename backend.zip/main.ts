import { Context, Elysia, t } from 'elysia';
import { swagger } from '@elysiajs/swagger';
import { cors } from '@elysiajs/cors';
import { PrismaClient } from '@prisma/client';
import auth from './auth/config';

export const prisma = new PrismaClient();

const app = new Elysia()
.use(cors({
    origin: 'http://localhost:3000', 
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true
}))
.post('/signup', async(context: Context) => {
    const { email, password, role } = await context.body as any;
    try {
        const user = await prisma.users.create({
            data: { email, password, role },
        });
        return { message: "User created successfully", user };
    } catch (error) {
        return { status: 500, body: { error: "Error creating user" } };
    }
})
.post('/login', async(context: Context) => {
    
})
.post('/signout', async(context: Context) => {

})
.listen(3001);

export type App = typeof app;

console.log(`Listening on ${app.server!.url}`);